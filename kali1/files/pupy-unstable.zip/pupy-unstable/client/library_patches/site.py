import sys
import os
import __builtin__

PREFIXES = []
ENABLE_USER_SITE = False
USER_SITE = ''
USER_BASE = ''

def addpackage(sitedir, name, known_paths):
    pass

def addsitedir(sitedir, known_paths=None):
    pass

def check_enableusersite():
    return False

def getuserbase():
    return ''

def getusersitepackages():
    return []

def addusersitepackages(known_paths):
    return []

def getsitepackages():
    return []

def addsitepackages(known_paths):
    return []

def main():
    pass
