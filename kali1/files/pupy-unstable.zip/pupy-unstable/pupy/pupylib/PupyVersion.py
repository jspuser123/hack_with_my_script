# -*- coding: utf-8 -*-

__author__='Nicolas VERDIER'
__version__='v1.7-unstable'
__date__='Sep 15 2017'

BANNER="""
            _____                    _       _ _
 ___ ___   |  _  |_ _ ___ _ _    ___| |_ ___| | |   ___ ___
|___|___|  |   __| | | . | | |  |_ -|   | -_| | |  |___|___|
           |__|  |___|  _|_  |  |___|_|_|___|_|_|
                     |_| |___|

                   %s (%s)
"""%(__version__, __date__)

BANNER_INFO="""
Author:           Nicolas VERDIER  < @n1nj4sec > (contact@n1nj4.eu)
Bleeding edge:    https://github.com/n1nj4sec/pupy
"""
